<?php
//C0ded By Jehad Alqurashi
include 'config/database.php';
if($_SERVER['REQUEST_METHOD'] == "POST"){
    $fname = mysqli_real_escape_string($connect,htmlspecialchars($_POST['fname']));
    $lname = mysqli_real_escape_string($connect,htmlspecialchars($_POST['lname']));
    $username = mysqli_real_escape_string($connect,htmlspecialchars($_POST['username']));
    $email = mysqli_real_escape_string($connect,htmlspecialchars($_POST['email']));
    $passowrd = mysqli_real_escape_string($connect,htmlspecialchars($_POST['password']));
    $email=strtolower($email);
    $username = strtolower($username);
    echo $username;
    $connect->query("insert into users(username,email,password,fname,lname)values('$username','$email','$passowrd','$fname','$lname')");
    echo "<script>location.href='index.php'</script>";
}

?>

<!DOCTYPE html>
<html>
    <head>
            <meta charset="utf-8">
            <title>Register</title>
            <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
            <link rel="stylesheet" href="style/style1.css">
    </head>
<body>
<h1>Register</h1>
    <form action="" method="post">
        <input type="text" name="fname" placeholder="Enter your First Name">
        <input type="text" name="lname" placeholder="Enter your Last Name">
        <input type="text" name="username" placeholder="Enter your username">
        <input name="email" type="text" placeholder="Enter your email">
        <input name="password" type="password" placeholder="Enter your Password">
        <input type="submit" value="Register">
    </form>
</body>
</html>