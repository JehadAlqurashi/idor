<?php
//C0ded By Jehad Alqurashi
session_start();
include 'config/database.php';
if($_SERVER['REQUEST_METHOD'] == "POST"){
   $username = mysqli_real_escape_string($connect,$_POST['username']);
   $pass = mysqli_real_escape_string($connect,$_POST['password']);
   $username = strtolower($username);
   $pass = strtolower($pass);
   $login = $connect->query("select * from users where username='$username' and password='$pass'");
   if($login->num_rows){
       $data = $login->fetch_assoc();
       $_SESSION['logged'] = true;
       $_SESSION['userId'] = $data['id'];
       header("location:dashboard.php?id=" . $data['id']);
   }else{
       echo "Password or email is wrong";
   }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Login</title>
    <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
    <link rel="stylesheet" href="style/style1.css">
</head>
<body>
<h1>Login</h1>

<form action="" method="POST">
    <input name="username" type="text" placeholder="Enter your username">
    <input name="password" type="password" placeholder="Enter your Password">
    <input type="submit" value="Submit">
</form>
<a href="register.php">Register</a>
</body>
</html>
