<?php
//C0ded By Jehad Alqurashi
session_start();
if(!isset($_SESSION['logged'])){
    die();
}
include 'config/database.php';
$id= mysqli_real_escape_string($connect,htmlspecialchars($_GET['id']));
$info = $connect->query("select * from users where id='$id' ");
if(!$info->num_rows){
    die();
}
$info =$info->fetch_assoc();
$error = [];
$counter = 0;
if(isset($_POST['fname']) && isset($_POST['lname']) && isset($_POST['username']) && isset($_POST['email'])) {
    $fname = mysqli_real_escape_string($connect, htmlspecialchars($_POST['fname']));
    $lname = mysqli_real_escape_string($connect, htmlspecialchars($_POST['lname']));
    $username = mysqli_real_escape_string($connect, htmlspecialchars($_POST['username']));
    $email = mysqli_real_escape_string($connect,htmlspecialchars($_POST['email']));
    $userID = mysqli_real_escape_string($connect,htmlspecialchars($_POST['id']));
    if(empty($fname)){array_push($error,"First Name is required");$counter++;}
    if(empty($lname)){array_push($error,"Last Name is required");$counter++;}
    if(empty($username)){array_push($error,"Username is required");$counter++;}
    if(empty($email)){array_push($error,"Email is required");$counter++;}
    if($counter===0){
        $connect->query("update users set username='$username',fname='$fname',lname='$lname',email='$email' where id='$userID'");
        header("location:dashboard.php?id=" . $id);
    }

}
if(isset($_POST['password'])){
    $userID = mysqli_real_escape_string($connect,htmlspecialchars($_POST['id']));
    $pass = mysqli_real_escape_string($connect,htmlspecialchars($_POST['password']));
    if(empty($pass)){array_push($error,"Password is required");$counter++;}
    if($counter===0) {
        $connect->query("update users set password='$pass' where id='$userID'");
    }
}
if(isset($_POST['delete'])){
    $userID = mysqli_real_escape_string($connect,htmlspecialchars($_POST['id']));
    $connect->query("delete from users where id='$userID'");
    header("location:index.php");
}
if(isset($_POST['send'])){
    $target= basename($_FILES['up']['name']);
    $ext = strtolower(pathinfo($target,PATHINFO_EXTENSION));
    if($ext!="jpg" && $ext!="pdf"){
        echo "Sorry file must be jpg or pdf";
    }else{
        $final = $_GET['id'] . '.' . $ext;
        $path = "/upload/" . $final;
        move_uploaded_file($_FILES['up']['tmp_name'],getcwd() . "/upload/" . $final);
        $connect->query("update users set image='$path' where id='$id'");
    }
}
?>
<title>Dashboard</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-wEmeIV1mKuiNpC+IOBjI7aAzPcEZeedi5yW5f2yOq55WWLwNGmvvx4Um1vskeMj0" crossorigin="anonymous">
<link rel="stylesheet" href="style/dash.css">
<div class="container rounded bg-white mt-5 mb-5">
    <form action="" method="post" >
    <div class="row">

        <button name="delete" class="btn btn-danger profile-button">Delete Account</button>
        <input type="hidden" name="id" value="<?php echo $_GET['id']; ?>">
        <div class="col-md-5 border-right">
    </form>
    <br>
    <button name="logout" class="btn btn-danger profile-button">logout</button>
            <div class="p-3 py-5">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h4 class="text-right">Profile Settings</h4><br>


                </div>
                <?php if(count($error)){
                    foreach ($error as $er){
                        echo $er . "<br>";
                    }
                } ?>
                <form action="" method="post">
                <div class="row mt-2">
                    <div class="col-md-6"><label class="labels">First Name</label><input type="text" name="fname" class="form-control" placeholder="first name" value="<?php echo $info['fname']; ?>"></div>
                    <div class="col-md-6"><label class="labels">Last Name</label><input type="text" name="lname" class="form-control" value="<?php echo $info['lname'] ?>" placeholder="last name"></div>
                </div>
                <div class="row mt-3">
                    <div class="col-md-12"><label class="labels">Username</label><input type="text" name="username" class="form-control" placeholder="Username" value="<?php echo $info['username'] ?>"></div>
                    <div class="col-md-12"><label class="labels">Email ID</label><input type="text" name="email" class="form-control" placeholder="Email" value="<?php echo $info['email']; ?>"><input type="hidden" name="id" value="<?php echo $_GET['id']; ?>"></div>
                </div>
                <div class="mt-5 text-center">
                    <button class="btn btn-primary profile-button">Save Profile</button></div>
            </div>
            </form>
        </div>

        <div class="col-md-4" >
            <br><br><br><br><br><br>
            <label class="labels" style="margin-top: 20px">New Password</label>
            <form action="" method="post">
            <input name="password" type="text" class="form-control" style="width: 300px"><br>
            <button class="btn btn-primary profile-button">Change Passwords</button>
                <input type="hidden" name="id" value="<?php echo $_GET['id']; ?>">
            </form>
        </div>
<div class="col-md-4" >
    <br><br><br><br>
    <label class="labels">Upload Your CV</label>
    <form action="" method="post" enctype="multipart/form-data">
        <input name="up" type="file" class="form-control" style=""><br>
        <button name="send" class="btn btn-primary profile-button">Upload</button>
    </form>
    <br>
    <?php
        $image = $connect->query("select image from users where id='$id'");
        if($image->num_rows){
            $ret = $image->fetch_assoc();
            ?>
            <a href="<?php echo '/idor/' .$ret['image'] ?>">CV</a>
    <?php
        }
    ?>
</div>
    </div>
</div>
</div>
</div>